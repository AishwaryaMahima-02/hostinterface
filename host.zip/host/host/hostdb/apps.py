from django.apps import AppConfig


class HostdbConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hostdb'
