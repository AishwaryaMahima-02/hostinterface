from django.db import models

# Create your models here.
class Partner(models.Model):
    org_name = models.CharField(max_length=100, null=False)
    org_num = models.CharField(max_length=100)
    org_email = models.EmailField(max_length=250)

    def __str__(self):
        return "%s %s %s" %(self.org_name, self.org_num, self.org_email)

class Event(models.Model):
    event_name = models.CharField(max_length=200)
    event_type=models.CharField(max_length=200, default="event")
    host_name = models.CharField(max_length=200)
    event_date = models.CharField(max_length=200)
    venue = models.CharField(max_length=200)
    fees = models.IntegerField(default=0)

    def __str__(self):
        return "%s %s %s %s %s" %(self.event_name, self.host_name, self.event_date, self.venue, self.fees)
