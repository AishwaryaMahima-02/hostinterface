
from django.http import HttpResponse
from django.shortcuts import render

from .models import Partner, Event
# Create your views here.
def home(request):
    return render(request, 'home.html')

def hlogin(request):
    return render(request, 'hlogin.html')

def ulogin(request):
    return render(request, 'ulogin.html')

def partner(request):
    part = Partner.objects.all()
    context = {
        'part' : part
    }
    print(context)
    return render(request, 'Partner.html', context)

def addevent(request):

    if request.method=='POST':
        event_name = request.POST['event_name']
        event_type = request.POST['event_type']
        host_name = request.POST['host_name'],
        event_date = request.POST['event_date'],
        venue = request.POST['venue'],
        fees = int(request.POST['fees'])
        new_event = Event(event_name=event_name, event_type=event_type, host_name=host_name, event_date=event_date, venue=venue, fees=fees)
        new_event.save()
        return HttpResponse('Event added Successfully')

    elif request.method == 'GET':
        return render(request, 'addevent.html')

    else:
        return HttpResponse('Error')

def viewevent(request):
    vevent = Event.objects.all()
    context = {
        'vevent' : vevent
    }
    print(context)
    return render(request, 'viewevent.html', context)